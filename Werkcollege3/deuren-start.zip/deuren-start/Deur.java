/**
 * Deur met twee sensoren waarmee je kan detecteren of een muis van de ene kamer naar de andere
 * loopt. We noemen de beide kanten van een deur (en de overeenkomstige sensoren) 'links'
 * en 'rechts'.
 */
public class Deur
{
    // Vul de velden aan
    
    // Maak een constructor met twee parameters, een voor de kamer aan de linkerkant
    // van de deur, een voor de kamer aan de rechterkant
    
    /**
     * De linker sensor detecteert een muis.
     */
    public void linkerSensorAan() {
        // vul deze code aan
    }
    
    /**
     * De linker sensor detecteert geen muis.
     */
    public void linkerSensorUit() {
        // vul deze code aan
    }
    
    /**
     * De rechter sensor detecteert een muis.
     */
    public void rechterSensorAan() {
        // vul deze code aan
    }
    
    /**
     * De rechter sensor detecteert geen muis.
     */
    public void rechterSensorUit() {
        // vul deze code aan
    }
}
