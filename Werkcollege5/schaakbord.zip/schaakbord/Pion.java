import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Pion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pion extends Stuk
{
    public Pion (boolean wit) {
        super (5, wit);
    }
}
