import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Oefeningen op de for-lus.
 */
public class Schaakbord extends World
{

    /**
     * Constructor
     */
    public Schaakbord()
    {   
        // 8 x 8 cellen van 45 x 45 pixels
        super(8, 8, 45); 
        
        // hier aanvullen...
    }
}
