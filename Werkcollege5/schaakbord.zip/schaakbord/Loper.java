import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Loper here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Loper extends Stuk
{    
    public Loper (boolean wit) {
        super (2, wit);
    }

}
