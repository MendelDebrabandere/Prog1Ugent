import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Dame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Dame extends Stuk
{
    public Dame (boolean wit) {
        super (1, wit);
    }
}
