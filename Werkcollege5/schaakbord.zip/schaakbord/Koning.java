import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Koning here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Koning extends Stuk
{
    public Koning (boolean wit) {
        super (0, wit);
    }
}
