import java.util.ArrayList;

public class Sessie {
    
    private ArrayList<Kandidaat> kandidaten;

    public Sessie() {
        int aantal = 10; // later: willekeurig aantal deelnemers tussen 10 en 30 (30 inbegrepen).
        kandidaten = new ArrayList<>();
        for(int i=0; i<aantal; i++) {
            boolean isVrouw = i%2==0; // later: willekeurig
            kandidaten.add(new Kandidaat(isVrouw));
        }
    }

    public void doeSessie(boolean interesseInVrouwen) {
        // Print kandidaten en verwijder ongeschikte.
        // Hier aanvullen!

        // Print de resterende kandidaten.
        System.out.println(">> Geschikte kandidaten:");
        for(Kandidaat kandidaat: kandidaten){
            System.out.println(kandidaat.getNaam());
        }

        System.out.println();
    }

    private double bepaalMatch(Kandidaat kandidaat, boolean interesseInVrouwen){
        double match = 0.0;
        if(kandidaat.isVrouw() == interesseInVrouwen) {
            match = 1.0; // later: willekeurig kommagetal tussen 0 en 1 (1 niet inbegrepen)
        }
        return match;
    }

}
