import greenfoot.*;

/**
 * Sensor die detecteert wanneer er een muis passeert.
 */
public class Sensor extends Actor {
    
    public Sensor(Deur deur, boolean isLinks, boolean isHorizontaal){
    }
    
    public void act() 
    {
    }
}
