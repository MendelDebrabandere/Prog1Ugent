public class Kamer {

    public Kamer(Lamp lamp, int aantal) {
    }
    
    public void vermeerderMuizen() {
    }
    
    public void verminderMuizen() {
    }
}
