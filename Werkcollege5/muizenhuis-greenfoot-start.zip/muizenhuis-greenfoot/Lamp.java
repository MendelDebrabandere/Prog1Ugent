import greenfoot.*;


public class Lamp extends Actor {
    public Lamp(boolean aan) {
    }
}
