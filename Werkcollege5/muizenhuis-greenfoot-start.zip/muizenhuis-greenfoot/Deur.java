public class Deur {
    private Kamer links;
    private Kamer rechts;
    
    public Deur(Kamer links, Kamer rechts) {
        this.links = links;
        this.rechts = rechts;
    }
    
    public void linkerSensorAan() {
    }
    
    public void linkerSensorUit() {
    }
    
    public void rechterSensorAan() {
    }
    
    public void rechterSensorUit() {
    }
}
