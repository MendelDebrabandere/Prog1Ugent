/**
 * Oefening Programmeren.
 * 
 * @author Benoit Desouter et al.
 * @version oktober 2014
 */
public class Pensioenregeling{
    public Pensioenregeling(){
    }
    
    /**
     * Bereken het pensioen op basis van de gegeven leeftijd.
     * Het tweede argument: true voor man, false voor vrouw.
     */
    public int geefPensioen(int leeftijd, boolean geslacht){
        // vul deze code aan    
    }
}
