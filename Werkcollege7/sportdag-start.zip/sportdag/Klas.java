public class Klas {
    
    private int aantalLeerlingen;
    // Hier code aanvullen: veld om leerlingen bij te houden.

    public Klas(){
        aantalLeerlingen = 20;
        // Hier code aanvullen!
    }

    public void voerKlassikaleStemmingUit(Activiteit[] activiteiten) {
        // Hier code aanvullen!
    }

}
