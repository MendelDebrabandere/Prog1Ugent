public class Leerling {
    
    public Leerling(){
    }

    public void brengStemUit(Activiteit[] activiteiten){
        // Hier code aanvullen!
    }

}
