public class School {
    // Activiteiten
    private int aantalActiviteiten;
    private Activiteit[] activiteiten;
    
    // Klassen
    private int aantalKlassen;
    // Hier code aanvullen: veld om klassen bij te houden.

    public School(){
        aantalActiviteiten = 5;
        activiteiten = new Activiteit[5];
        this.activiteiten[0] = new Activiteit("Muurklimmen");
        this.activiteiten[1] = new Activiteit("Zumba");
        this.activiteiten[2] = new Activiteit("Minigolf");
        this.activiteiten[3] = new Activiteit("Tennis");
        this.activiteiten[4] = new Activiteit("Zaalvoetbal");

        aantalKlassen = 10;
        // Initialiseer klassen.
        // Hier code aanvullen!
    }
    
    public Activiteit[] getActiviteiten(){
        return activiteiten;
    }
    
    public void voerStemmingUit(){
        // Hier code aanvullen!
    }
    
    public void printResultaten(){
        for(Activiteit activiteit: activiteiten){
            System.out.println(activiteit.getNaam() + ": " + activiteit.getAantalStemmen());
        }
        System.out.println();
    }
    
    public int getTotaalAantalStemmen(){
        int totaalAantalStemmen = 0;
        // Hier code aanpassen!
        return totaalAantalStemmen;
    }
    
    public Activiteit getPopulairsteActiviteit(){
        Activiteit activiteit = null;
        // Hier code aanpassen!
        return activiteit;
    }

    public Activiteit getMinstPopulaireActiviteit(){
        Activiteit activiteit = null;
        // Hier code aanpassen!
        return activiteit;
    }
    
}
