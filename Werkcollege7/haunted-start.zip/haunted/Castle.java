import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * In dit kasteel dwalen er twee spoken rond...
 */
public class Castle extends World {  

    /**
     * Constructor for objects of class Castle.     * 
     */
    public Castle() {    
        // Opgelet: de cellen zijn 8x8 maar de muurdelen zijn 32x32!
        super(57, 57, 8); 
        Greenfoot.setSpeed(36);

        // Plaats de muren en de spoken op de wereld, zoals in de
        // plattegrond
    }
}
