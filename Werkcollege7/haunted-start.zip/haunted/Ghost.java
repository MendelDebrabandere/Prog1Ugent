import greenfoot.*;
import java.util.Random;

/**
 * Een spook dat door het kasteel dwaalt.
 */
public class Ghost extends Actor {

    /**
     * Bij elk kruispunt kan het spook een andere (willekeurige) richting nemen. 
     * Het spook keert echter enkel op zijn stappen terug als het niet anders kan.
     */
    public void act() {
        // Aanpassen aub!
    }    
}
