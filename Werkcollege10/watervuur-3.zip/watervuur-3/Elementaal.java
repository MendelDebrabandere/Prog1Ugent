import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;

public class Elementaal extends Actor
{
    private static Random RG = new Random ();

    private int richting;
    private int leeftijd; // enkel gebruikt door Wachter en Terugtrekker

    public Elementaal (int leeftijd) {
        this.leeftijd = leeftijd;
        this.richting = 0;
    }
    
    public void keerOm () {
        richting = (richting + 180) % 360;
    }
    
    /**
     * Beweeg zonder de orientatie van de prent aan te passen
     */
    public void glijd () {
        setRotation(richting);
        move(1);
        setRotation(0);
    }

    public void setRichting (int richting) {
        this.richting = richting;
    }
    
    public int getRichting () {
        return richting;
    }

    public void vervangDoor (Actor actor) {
        actor.setImage(getImage());
        getWorld().addObject(actor, getX(), getY());
        getWorld().removeObject(this);
    }
    
    public boolean leeftijdIsNul () {
        return leeftijd == 0;
    }
    
    public void verminderLeeftijd () {
        leeftijd -- ;
    }

}
